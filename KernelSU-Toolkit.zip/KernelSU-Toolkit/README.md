# KernelSU Toolkit

整合了 **Payload-Dumper-Android**、**KSuRoot** 和 **GhostLock-App** 三大开源项目的 Android 内核提权工具套件。

## 📱 功能特性

### 1. OTA 包提取 (来自 Payload-Dumper-Android)
- 直接在 Android 设备上提取 `payload.bin` 或 `OTA.zip`
- 支持提取 boot、vendor_boot、system 等分区镜像
- 实时进度显示和完整性校验
- 并行提取加速

### 2. 内核偏移量提取 (来自 GhostLock-App)
- 从 `boot.img` 自动解析内核符号表
- 支持 45+ 款设备的 offsets.h 配置
- Rust 提取器集成（kallsyms_finder + disasm）
- 自动生成适配本机的载荷配置

### 3. 一键 KernelSU 提权 (来自 KSuRoot)
- 基于 CVE-2026-43499 (GhostLock) 漏洞
- 无需解锁 Bootloader
- 内核 6.6+ 免 ADB 直接执行
- 三种载荷来源：官方在线 / 内置动态库 / 自定义构建
- 液态玻璃 UI (MIUIX 风格)

## 🏗️ 项目结构

```
KernelSU-Toolkit/
├── app/
│   ├── src/main/
│   │   ├── java/com/toolkit/kernelsu/
│   │   │   ├── MainActivity.kt              # 主活动
│   │   │   ├── extractor/                    # OTA 提取模块
│   │   │   │   └── OTAPayloadExtractor.kt   # payload.bin 解析
│   │   │   ├── payload/                      # 载荷管理
│   │   │   │   ├── PayloadBuilder.kt        # 载荷构建
│   │   │   │   └── PayloadRepository.kt     # 载荷仓库
│   │   │   ├── exploit/                      # 漏洞利用
│   │   │   │   └── GhostLockExploit.kt      # GhostLock 核心
│   │   │   ├── kernelpack/                   # 内核解析 (来自 KSuRoot)
│   │   │   │   ├── boot/BootImageParser.kt  # boot.img 解析
│   │   │   │   ├── kallsyms/KallsymsFinder.kt
│   │   │   │   ├── patch/AArch64.kt         # ARM64 指令补丁
│   │   │   │   └── resolve/OffsetResolver.kt
│   │   │   └── ui/                           # Compose UI
│   │   │       ├── screens/MainScreen.kt    # 主界面 (三标签页)
│   │   │       ├── theme/                    # 主题配置
│   │   │       └── glass/                    # 液态玻璃组件
│   │   ├── cpp/                              # NDK 原生代码
│   │   │   ├── ghostlock/                    # GhostLock C 核心
│   │   │   │   ├── main.c
│   │   │   │   ├── fops.c
│   │   │   │   └── offsets_json.c
│   │   │   └── payload/                      # Payload 辅助库
│   │   ├── AndroidManifest.xml
│   │   └── res/                              # 资源文件
│   └── build.gradle.kts
├── gradle/libs.versions.toml                 # 依赖版本目录
├── build.gradle.kts
└── settings.gradle.kts
```

## 🔧 技术栈

| 组件 | 技术 |
|------|------|
| **UI 框架** | Jetpack Compose + Material 3 |
| **语言** | Kotlin 2.1.20 + C/C++ (NDK) |
| **最低版本** | Android 8.0 (API 26) |
| **目标版本** | Android 15 (API 35) |
| **原生编译** | CMake 3.22 + Clang |
| **依赖管理** | Gradle Version Catalogs |

### 核心依赖
- `rikka.shizuku:api:13.1.5` - Shizuku API
- `org.apache.commons:commons-compress:1.27.1` - ZIP/payload 解压
- `com.google.protobuf:protobuf-kotlin-lite:4.29.3` - OTA 元数据解析
- `io.coil-kt:coil-compose:2.7.0` - 图片加载

## 🚀 构建指南

### 前置条件
1. Android Studio Hedgehog (2023.1.1) 或更高版本
2. NDK r26+ (推荐 r29)
3. CMake 3.22+
4. JDK 17

### 编译步骤

```bash
# 1. 克隆项目
git clone https://github.com/your-repo/KernelSU-Toolkit.git
cd KernelSU-Toolkit

# 2. 同步 Gradle 依赖
./gradlew sync

# 3. 整合原始源码 (可选，用于参考完整实现)
cp -r ../Payload-Dumper-Android-main/lib ./app/src/main/cpp/payload-dumper-rs
cp -r ../ghostlock-app-main/src/core/* ./app/src/main/cpp/ghostlock/
cp -r ../KSuRoot-main/app/src/main/java/com/kernelpack/* ./app/src/main/java/com/toolkit/kernelsu/kernelpack/

# 4. 编译 Debug 版
./gradlew assembleDebug

# 5. 编译 Release 版 (需签名配置)
./gradlew assembleRelease
```

### APK 输出位置
- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release: `app/build/outputs/apk/release/app-release-unsigned.apk`

## 📖 使用流程

### 场景 1：从官方 OTA 提权
1. 下载设备对应的 OTA.zip
2. 打开 **OTA 提取** 标签页 → 选择 OTA.zip
3. 提取 `boot.img` 分区
4. 切换到 **偏移提取** → 选择刚提取的 boot.img
5. 等待自动解析内核符号
6. 切换到 **一键提权** → 点击"开始提权"

### 场景 2：使用内置载荷 (支持设备)
1. 直接打开 **一键提权** 标签页
2. 应用自动检测设备型号和内核版本
3. 如果匹配内置载荷，直接点击"开始提权"

### 场景 3：自定义载荷构建
1. 从 fastboot 模式提取当前设备的 boot.img
2. **偏移提取** → 加载 boot.img
3. 手动调整关键偏移量（如有必要）
4. 点击"生成载荷"
5. 切换到 **一键提权** → 选择"自定义载荷"

## ⚠️ 风险提示

- **变砖风险**：内核级漏洞利用可能导致设备无法启动
- **保修失效**：部分厂商会检测 root 状态并拒绝保修
- **数据安全**：建议操作前备份重要数据
- **安全机制**：可能触发 Knox、Find My Mobile 等安全功能

**仅建议在自有测试设备上使用！**

## 📄 许可证

本项目整合的源码分别遵循：
- Payload-Dumper-Android: GPL-3.0
- KSuRoot: Apache-2.0
- GhostLock-App: 未明确（与原项目保持一致）

整合后的新项目建议采用 **Apache-2.0** 许可证。

## 🙏 致谢

- [Payload-Dumper-Android](https://github.com/Rajmani7584/Payload-Dumper-Android) - OTA 提取引擎
- [KSuRoot](https://github.com/hmascs/KSuRoot) - 产品化提权框架
- [GhostLock-App](https://github.com/ghostlock-team/ghostlock-app) - 漏洞利用原实现

---

*本工具仅供学习和研究使用，请勿用于非法用途。*
