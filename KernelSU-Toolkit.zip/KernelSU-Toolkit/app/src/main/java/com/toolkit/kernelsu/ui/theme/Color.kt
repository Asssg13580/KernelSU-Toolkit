package com.toolkit.kernelsu.ui.theme

import androidx.compose.ui.graphics.Color

// 深色主题配色（液态玻璃风格）
val GlassBackground = Color(0xFF0A0E14)
val GlassSurface = Color(0xFF151A23)
val GlassPrimary = Color(0xFF00C896)
val GlassSecondary = Color(0xFF7B61FF)
val GlassAccent = Color(0xFFFF6B6B)
val GlassTextPrimary = Color(0xFFFFFFFF)
val GlassTextSecondary = Color(0xFFA0A8B0)

// 渐变配置
val PrimaryGradient = listOf(GlassPrimary, Color(0xFF00D4AA))
val SecondaryGradient = listOf(GlassSecondary, Color(0xFF9D82FF))
val DangerGradient = listOf(GlassAccent, Color(0xFFFF8F8F))
