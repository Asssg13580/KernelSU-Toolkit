package com.toolkit.kernelsu.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.toolkit.kernelsu.ui.theme.GlassSurface
import com.toolkit.kernelsu.ui.theme.PrimaryGradient

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    var selectedTab by remember { mutableStateOf(0) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "KernelSU Toolkit",
                        fontWeight = FontWeight.Bold
                    ) 
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = GlassSurface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // 标签页导航
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = GlassSurface,
                contentColor = MaterialTheme.colorScheme.onSurface
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("OTA 提取") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("偏移提取") }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("一键提权") }
                )
            }
            
            // 内容区域
            when (selectedTab) {
                0 -> OTAPayloadExtractorScreen()
                1 -> OffsetExtractorScreen()
                2 -> OneClickRootScreen()
            }
        }
    }
}

@Composable
fun OTAPayloadExtractorScreen() {
    var otaFile by remember { mutableStateOf<String?>(null) }
    var isExtracting by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var extractedPartitions by remember { mutableStateOf(listOf<String>()) }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GlassSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "选择 OTA 包",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "支持 payload.bin 或 OTA.zip 格式",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { /* TODO: 实现文件选择 */ },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Brush.horizontalGradient(PrimaryGradient)
                    )
                ) {
                    Text("选择文件")
                }
                otaFile?.let { file ->
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "已选：${file.substringAfterLast('/')}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        
        if (isExtracting) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GlassSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "提取中...",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "${(progress * 100).toInt()}%",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        
        if (extractedPartitions.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GlassSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "已提取分区",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyColumn {
                        items(extractedPartitions) { partition ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    partition,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OffsetExtractorScreen() {
    var bootImage by remember { mutableStateOf<String?>(null) }
    var isExtracting by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GlassSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "选择 boot.img",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "从 boot 镜像中提取内核符号和偏移量",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { /* TODO: 实现文件选择 */ },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("选择 boot.img")
                }
                bootImage?.let { file ->
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "已选：${file.substringAfterLast('/')}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        
        if (isExtracting) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GlassSurface)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
        }
        
        result?.let { res ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GlassSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "提取结果",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        res,
                        style = MaterialTheme.typography.bodyMedium,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
fun OneClickRootScreen() {
    var isRooting by remember { mutableStateOf(false) }
    var rootStatus by remember { mutableStateOf<RootStatus>(RootStatus.NotRooted) }
    var logs by remember { mutableStateOf(listOf<String>()) }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 状态卡片
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = when (rootStatus) {
                    RootStatus.Rooted -> MaterialTheme.colorScheme.primary
                    RootStatus.Failed -> MaterialTheme.colorScheme.error
                    else -> GlassSurface
                }
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = when (rootStatus) {
                            RootStatus.Rooted -> "✓ 已获取 Root"
                            RootStatus.Failed -> "✗ 提权失败"
                            RootStatus.NotRooted -> "未 Root"
                            RootStatus.InProgress -> "提权中..."
                        },
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = when (rootStatus) {
                            RootStatus.Rooted -> MaterialTheme.colorScheme.onPrimary
                            RootStatus.Failed -> MaterialTheme.colorScheme.onError
                            else -> MaterialTheme.colorScheme.onSurface
                        }
                    )
                }
            }
        }
        
        // 操作按钮
        Button(
            onClick = { /* TODO: 实现提权逻辑 */ },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isRooting && rootStatus == RootStatus.NotRooted,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (rootStatus == RootStatus.NotRooted) 
                    MaterialTheme.colorScheme.primary 
                else MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Text(if (isRooting) "执行中..." else "开始提权")
        }
        
        // 日志输出
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            colors = CardDefaults.cardColors(containerColor = GlassSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "执行日志",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.3f))
                        .padding(8.dp)
                ) {
                    LazyColumn {
                        items(logs) { log ->
                            Text(
                                log,
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                color = Color(0xFF00FF00)
                            )
                        }
                    }
                }
            }
        }
    }
}

enum class RootStatus {
    NotRooted,
    InProgress,
    Rooted,
    Failed
}
