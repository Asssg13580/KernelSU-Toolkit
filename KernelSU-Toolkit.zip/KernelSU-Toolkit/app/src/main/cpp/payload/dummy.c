// 占位文件
#include <jni.h>
#include <android/log.h>

#define LOG_TAG "PayloadDummy"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)

JNIEXPORT jint JNICALL
Java_com_toolkit_kernelsu_payload_PayloadDummy_nativeTest(
        JNIEnv *env,
        jobject thiz) {
    LOGD("Payload dummy called");
    return 0;
}
